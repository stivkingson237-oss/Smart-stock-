# SmartStock Pro
App statique (index.html) + Supabase (tables : products, sales, stock_movements, boutiques, subscriptions, memberships).

## Déploiement
git init && git add . && git commit -m "SmartStock Pro"
git branch -M main
git remote add origin https://github.com/<ton-user>/smartstock-pro.git
git push -u origin main
# puis Vercel > Add New Project > importer le repo (Framework: Other)
